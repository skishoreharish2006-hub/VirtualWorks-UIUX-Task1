
  # Modern Website Redesign

  This is a code bundle for Modern Website Redesign. The original project is available at https://www.figma.com/design/PY8DXwidJBehHB9gsn2SWk/Modern-Website-Redesign.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  