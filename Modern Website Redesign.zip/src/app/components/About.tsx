import { Target, Users, Award, TrendingUp } from "lucide-react";

const features = [
  {
    icon: Target,
    title: "Mission Driven",
    description: "We focus on delivering solutions that align with your business goals and drive measurable results."
  },
  {
    icon: Users,
    title: "Expert Team",
    description: "Our talented team brings years of experience in design, development, and digital strategy."
  },
  {
    icon: Award,
    title: "Quality First",
    description: "We maintain the highest standards of quality in every project, ensuring excellence in every detail."
  },
  {
    icon: TrendingUp,
    title: "Growth Focused",
    description: "We build scalable solutions designed to grow with your business and adapt to changing needs."
  }
];

export function About() {
  return (
    <section id="about" className="py-20 px-8 bg-gray-50">
      <div className="max-w-[1440px] mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-black mb-4">About Us</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            We're a team of passionate designers and developers dedicated to creating
            exceptional digital experiences that transform businesses.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div
                key={index}
                className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-md transition-shadow border border-gray-100"
              >
                <div className="w-14 h-14 bg-gradient-to-br from-[#6C63FF] to-[#9D97FF] rounded-xl flex items-center justify-center mb-6">
                  <Icon size={28} className="text-white" />
                </div>
                <h3 className="text-xl font-semibold text-black mb-3">{feature.title}</h3>
                <p className="text-gray-600 leading-relaxed">{feature.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
