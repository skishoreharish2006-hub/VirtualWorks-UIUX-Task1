import { Menu, X } from "lucide-react";
import { useState } from "react";

export function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setIsMenuOpen(false);
    }
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white border-b border-gray-200">
      <div className="max-w-[1440px] mx-auto px-8 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#6C63FF] to-[#9D97FF] flex items-center justify-center">
              <span className="text-white font-bold text-xl">D</span>
            </div>
            <span className="text-xl font-semibold text-black">Digital</span>
          </div>

          <div className="hidden md:flex items-center gap-8">
            <button onClick={() => scrollToSection("hero")} className="text-gray-600 hover:text-[#6C63FF] transition-colors">
              Home
            </button>
            <button onClick={() => scrollToSection("about")} className="text-gray-600 hover:text-[#6C63FF] transition-colors">
              About
            </button>
            <button onClick={() => scrollToSection("services")} className="text-gray-600 hover:text-[#6C63FF] transition-colors">
              Services
            </button>
            <button onClick={() => scrollToSection("contact")} className="text-gray-600 hover:text-[#6C63FF] transition-colors">
              Contact
            </button>
            <button
              onClick={() => scrollToSection("contact")}
              className="px-6 py-2 bg-[#6C63FF] text-white rounded-lg hover:bg-[#5850e6] transition-colors"
            >
              Get Started
            </button>
          </div>

          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden text-gray-600"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4 flex flex-col gap-4">
            <button onClick={() => scrollToSection("hero")} className="text-gray-600 hover:text-[#6C63FF] transition-colors text-left">
              Home
            </button>
            <button onClick={() => scrollToSection("about")} className="text-gray-600 hover:text-[#6C63FF] transition-colors text-left">
              About
            </button>
            <button onClick={() => scrollToSection("services")} className="text-gray-600 hover:text-[#6C63FF] transition-colors text-left">
              Services
            </button>
            <button onClick={() => scrollToSection("contact")} className="text-gray-600 hover:text-[#6C63FF] transition-colors text-left">
              Contact
            </button>
            <button
              onClick={() => scrollToSection("contact")}
              className="px-6 py-2 bg-[#6C63FF] text-white rounded-lg hover:bg-[#5850e6] transition-colors text-left"
            >
              Get Started
            </button>
          </div>
        )}
      </div>
    </nav>
  );
}
