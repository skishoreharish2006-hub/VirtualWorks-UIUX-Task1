import { Zap, Shield, HeartHandshake, Rocket } from "lucide-react";

const features = [
  {
    icon: Zap,
    title: "Fast Delivery",
    description: "We work efficiently to deliver your project on time without compromising quality."
  },
  {
    icon: Shield,
    title: "Reliable & Secure",
    description: "Your data and projects are safe with us. We follow industry best practices for security."
  },
  {
    icon: HeartHandshake,
    title: "Client-Focused",
    description: "Your success is our priority. We listen, collaborate, and deliver solutions that exceed expectations."
  },
  {
    icon: Rocket,
    title: "Innovation First",
    description: "We stay ahead of trends, using cutting-edge technologies to give you a competitive edge."
  }
];

export function WhyChooseUs() {
  return (
    <section className="py-20 px-8 bg-gradient-to-br from-[#6C63FF] to-[#5850e6] text-white">
      <div className="max-w-[1440px] mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">Why Choose Us</h2>
          <p className="text-lg text-white/90 max-w-2xl mx-auto">
            We combine expertise, innovation, and dedication to deliver exceptional results
            that help your business thrive.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div
                key={index}
                className="bg-white/10 backdrop-blur-sm p-8 rounded-2xl border border-white/20 hover:bg-white/20 transition-all"
              >
                <div className="w-14 h-14 bg-[#E8FF3D] rounded-xl flex items-center justify-center mb-6">
                  <Icon size={28} className="text-[#6C63FF]" />
                </div>
                <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                <p className="text-white/80 leading-relaxed">{feature.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
