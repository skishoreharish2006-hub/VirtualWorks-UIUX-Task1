import { Palette, Code, Sparkles } from "lucide-react";

const services = [
  {
    icon: Palette,
    title: "UI/UX Design",
    description: "Create intuitive, beautiful interfaces that users love. We design with purpose, focusing on usability and aesthetics.",
    features: ["User Research", "Wireframing", "Prototyping", "Visual Design"]
  },
  {
    icon: Code,
    title: "Web Development",
    description: "Build fast, responsive websites and web applications using modern technologies and best practices.",
    features: ["React & Next.js", "Responsive Design", "Performance Optimization", "API Integration"]
  },
  {
    icon: Sparkles,
    title: "Branding",
    description: "Develop a strong brand identity that resonates with your audience and stands out in the market.",
    features: ["Brand Strategy", "Logo Design", "Brand Guidelines", "Marketing Materials"]
  }
];

export function Services() {
  return (
    <section id="services" className="py-20 px-8">
      <div className="max-w-[1440px] mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-black mb-4">Our Services</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Comprehensive digital solutions tailored to your needs. From design to development,
            we've got you covered.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <div
                key={index}
                className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-lg transition-all border border-gray-100 group"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-[#6C63FF] to-[#9D97FF] rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <Icon size={32} className="text-white" />
                </div>
                <h3 className="text-2xl font-semibold text-black mb-4">{service.title}</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">{service.description}</p>
                <ul className="space-y-2">
                  {service.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center gap-2 text-gray-700">
                      <div className="w-1.5 h-1.5 rounded-full bg-[#E8FF3D]"></div>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
