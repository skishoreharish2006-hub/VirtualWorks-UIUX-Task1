import { Star } from "lucide-react";

const testimonials = [
  {
    name: "Sarah Johnson",
    role: "CEO, TechStart Inc",
    content: "Working with this team transformed our online presence. The attention to detail and creative solutions exceeded our expectations. Highly recommend!",
    rating: 5
  },
  {
    name: "Michael Chen",
    role: "Founder, GrowthLab",
    content: "The team delivered a stunning website that perfectly captures our brand. Their professionalism and expertise made the entire process smooth and enjoyable.",
    rating: 5
  },
  {
    name: "Emily Rodriguez",
    role: "Marketing Director, Innovate Co",
    content: "From concept to launch, they were fantastic. Our new branding has helped us stand out in a crowded market. Couldn't be happier with the results!",
    rating: 5
  }
];

export function Testimonials() {
  return (
    <section className="py-20 px-8">
      <div className="max-w-[1440px] mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-black mb-4">What Our Clients Say</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Don't just take our word for it. Here's what our satisfied clients have to say
            about working with us.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-md transition-shadow border border-gray-100"
            >
              <div className="flex gap-1 mb-6">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} size={20} className="fill-[#E8FF3D] text-[#E8FF3D]" />
                ))}
              </div>
              <p className="text-gray-700 leading-relaxed mb-6">"{testimonial.content}"</p>
              <div>
                <p className="font-semibold text-black">{testimonial.name}</p>
                <p className="text-sm text-gray-600">{testimonial.role}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
