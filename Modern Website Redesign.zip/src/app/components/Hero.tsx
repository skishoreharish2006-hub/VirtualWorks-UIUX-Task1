import { ArrowRight } from "lucide-react";

export function Hero() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="hero" className="pt-32 pb-20 px-8">
      <div className="max-w-[1440px] mx-auto">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <div className="space-y-8">
            <h1 className="text-5xl md:text-6xl font-bold text-black leading-tight">
              We Create Digital Solutions That Grow Your Business
            </h1>
            <p className="text-lg text-gray-600 leading-relaxed">
              Transform your vision into reality with cutting-edge design and development.
              We build modern, scalable solutions that drive results and deliver exceptional user experiences.
            </p>
            <div className="flex flex-wrap gap-4">
              <button
                onClick={() => scrollToSection("services")}
                className="px-8 py-4 bg-[#6C63FF] text-white rounded-lg hover:bg-[#5850e6] transition-all flex items-center gap-2 shadow-lg shadow-[#6C63FF]/20"
              >
                Explore Services
                <ArrowRight size={20} />
              </button>
              <button
                onClick={() => scrollToSection("portfolio")}
                className="px-8 py-4 bg-white border-2 border-[#6C63FF] text-[#6C63FF] rounded-lg hover:bg-[#6C63FF] hover:text-white transition-all"
              >
                View Portfolio
              </button>
            </div>
          </div>

          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-br from-[#6C63FF] to-[#E8FF3D] rounded-3xl opacity-20 blur-3xl"></div>
            <img
              src="https://images.unsplash.com/photo-1635776062127-d379bfcba9f8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080"
              alt="Modern abstract gradient"
              className="relative rounded-3xl shadow-2xl w-full h-[500px] object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
